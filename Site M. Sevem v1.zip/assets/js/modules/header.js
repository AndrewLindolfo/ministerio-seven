export function initHeader() {}

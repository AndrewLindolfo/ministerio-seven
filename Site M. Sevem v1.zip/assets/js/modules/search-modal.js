export function initSearchModal() {}

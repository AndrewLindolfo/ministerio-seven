export function initThemeToggle() {}

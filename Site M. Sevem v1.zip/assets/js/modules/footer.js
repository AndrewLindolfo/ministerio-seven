export function initFooter() {}
